namespace GeoAPI.Geometries
{
    public interface IMultiSurface : IGeometryCollection
    {
    }
}
