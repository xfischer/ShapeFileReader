namespace GeoAPI.Geometries
{
    public interface ISurface : IGeometry { }
}
