namespace GeoAPI.Geometries
{
    public interface IMultiPolygon : IMultiSurface, IPolygonal
    {
    }
}
