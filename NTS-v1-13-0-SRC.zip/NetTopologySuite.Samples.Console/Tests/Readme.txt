Run this tests with TestDriven.NET plugin for VS2005!
Simply install the plugin @ http://www.testdriven.net/,
then click with the mouse right-button and ... launch test!
Could be more easier than this? :)
[=> yes, you can assign it a keyboard shortcut :-P]
