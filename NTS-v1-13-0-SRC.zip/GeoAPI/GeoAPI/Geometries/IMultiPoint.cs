namespace GeoAPI.Geometries
{
    public interface IMultiPoint : IGeometryCollection, IPuntal
    {
    }
}
