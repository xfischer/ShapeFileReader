﻿namespace GeoAPI
{
    public interface ICloneable
    {
        object Clone();
    }
}
