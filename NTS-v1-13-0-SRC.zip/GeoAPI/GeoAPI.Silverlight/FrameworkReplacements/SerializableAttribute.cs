#if SILVERLIGHT
namespace System
{
    public class SerializableAttribute : Attribute
    {
    }
    public class NonSerializedAttribute : Attribute
    {
    }

}
#endif